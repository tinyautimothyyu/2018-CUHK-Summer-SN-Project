#!/bin/bash
make clean
make cleanfile
make
./star_weno
